SalvattorePortfolioTemplate
===========================

Salvattore Portfolio Template which i'm building my portfolio,
Since some people have issues with getting Salvattore to work, Here's a template to start with

Demo - http://udithishara.github.io/SalvattorePortfolioTemplate <br>
Responsive Demo - http://www.responsinator.com/?url=http://udithishara.github.io/SalvattorePortfolioTemplate

Credits:

	Css Reset - @html5doctor
	Placeholders - http://placehold.it
	Salvattore.js - @salvattorejs
	Template Setup - @UdithIshara ( if you want to )

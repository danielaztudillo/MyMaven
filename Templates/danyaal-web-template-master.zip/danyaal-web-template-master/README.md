#danyaal-web-template
A very simple portfolio website based on [thedanyaal.com](http://thedanyaal.com) & [lucilleofapproval.com](http://lucilleofapproval.com)
![ScreenShot](http://i.imgur.com/c6F9K7p.png)
If you have any questions, feel free to email me at danyaal@rangwa.la
